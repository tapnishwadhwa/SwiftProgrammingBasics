//: Playground - noun: a place where people can play

import UIKit

var age = 16

var weight = 185

//var someNum : Int = 12345537562347890755679 // TOO LONG FOR INT
var someNum : Double = 123456787654345678987654 // fits

var milesRan = 56.21

var pi : Float = 3.14



// Arithmetic operators 
// + - / *

var area = 15 * 20
var sum = 5+6
var diff = 3-10
var div = 12/4
var div1 = 12/5
var remainder = 12%5
var result = "The result of 13 divided by 5 is \(div1) with a remainder of \(remainder)"


var randomNo = 12
if randomNo % 2 == 0{
    print("its an even number")
}

else{
    print("its an odd number")
}