//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var length = 5
var width = 10
var area = length * width

var length2 = 6
var witdth2 = 12
var area2 = length2 * witdth2


var length3 = 12
var width3 = 12
var area3 = length3*width3


func calculateArea (length: Int, width:Int  ) -> Int {
    let area = length*width
    return area
    

}

let shape1 = calculateArea(length: 5, width: 4)
let shape2 = calculateArea(length: 6, width: 4)
let shape3 = calculateArea(length: 7, width: 4)



var bankActBln = 500.00
var rbkShoes = 265.00

func purchaseItem (currentBalance : inout Double, itemPrice: Double){
    if itemPrice <= currentBalance{
    currentBalance = currentBalance - itemPrice
        print ("Purchased Item for : $\(itemPrice)")
    } else {
        print("Your are broke , SAVE MONEYYY")
    }
}

purchaseItem(currentBalance: &bankActBln, itemPrice: rbkShoes)

var MBP = 40.0

purchaseItem(currentBalance: &bankActBln, itemPrice: MBP)


purchaseItem(currentBalance: &bankActBln, itemPrice: MBP)

purchaseItem(currentBalance: &bankActBln, itemPrice: MBP)

purchaseItem(currentBalance: &bankActBln, itemPrice: MBP)

purchaseItem(currentBalance: &bankActBln, itemPrice: MBP)

purchaseItem(currentBalance: &bankActBln, itemPrice: MBP)










