//: Playground - noun: a place where people can play

import UIKit

var amITheBest: Bool = true
amITheBest = false

if true == false || true == true {
    print ("WTF")
}

var hasDataFinishedDownload = false
//...


if !hasDataFinishedDownload{
    print("LOADING")
}
hasDataFinishedDownload = true
//Load UI and app features




// Equal to: ==
// Not equal to: !
// Greater than: a > b
// greater than or equal to: >=
// less than or equal to: <=
// less than: < 
var bankBalance = 400
var itemPrice = 400
if bankBalance >= itemPrice{
    print ("Purchased Item")
}

if itemPrice>bankBalance{
    print ("U NEED MORE MONEY ")
}

if itemPrice==bankBalance{
    print("YOU GOT ZERO")
}


var bookTitle1 = "Harry Pot"
var booktitle2 = "Harry Pot"
if bookTitle1 != booktitle2{
    print("Fix the spelling")
} else if booktitle2.characters.count > 10 {
    print ("Find a new title for the book")
}

else {
    print ("BOOK LOOKS GREAT SEND TO PRINTER")
}











