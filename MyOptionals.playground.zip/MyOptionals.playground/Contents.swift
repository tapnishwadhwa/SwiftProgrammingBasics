//: Playground - noun: a place where people can play

import UIKit

var lotteryWinning : Int?



if lotteryWinning != nil {
    print(lotteryWinning!)
}
 lotteryWinning = 100

if let winnigs = lotteryWinning{
    print (winnigs)
}

class Car {
    var model: String?
}

var vehicle: Car?



if let v = vehicle {
    if let m = v.model{
        print(m)
    }
}

print(vehicle?.model)

vehicle = Car()
vehicle?.model = "Tesla"

if let v = vehicle, let m = v.model{
    print(m)
}


var cars: [Car]?

//cars = [Car]()

if let carArr = cars , carArr.count > 0 {
 print ("HELLO")
} else {
    cars?.append(Car())
    print(cars?.count)
}


class Person{
     var age: Int!
    
    
    
    var _age: Int {
        
        if age == nil{
            age = 15
        }
        
    return age
        
    }
    func setAge(newAge: Int){
        self.age = newAge
    }

}

var jack = Person()
//print (jack.age)
print (jack._age)


class Dog {
    var species: String
    init(someSpescies:String) {
        self.species = someSpescies
    }
}

var lab = Dog(someSpescies: "Black Lab")
print (lab.species)


















