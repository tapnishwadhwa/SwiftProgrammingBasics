//: Playground - noun: a place where people can play

import UIKit

class shape {
    var area: Double?
    
    func calcArea(valA:Double, valB: Double){
        
    }
}

class triangle: shape {
    override func calcArea(valA: Double, valB: Double) {
        area = valA*valB/2
    }
}

class rectangle: shape{
    override func calcArea(valA: Double, valB: Double) {
        area = valB * valA
    }
}