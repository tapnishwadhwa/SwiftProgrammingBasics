//: Playground - noun: a place where people can play

import UIKit

var employee1Salary = 45000.0
var employee2Salary = 54000.00
var employee3Salary = 134000.0
var employee4Salary = 24000.0


var employeeSalaries: [Double] = [45000.0,54000.0,134000.0,24000.0]

print(employeeSalaries.count)
employeeSalaries.append(39000.42)

print(employeeSalaries.count)

employeeSalaries.remove(at: 1)

print(employeeSalaries.count)

var students = [String]()
print(students.count)

students.append("Jon")
students.append("Tap")
students.append("Seeam")
students.append("Rushi")
students.append("Harsim")

students.remove(at: 2)

print(students)