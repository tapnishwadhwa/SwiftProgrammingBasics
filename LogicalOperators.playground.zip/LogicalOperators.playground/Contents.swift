//: Playground - noun: a place where people can play

import UIKit

// Logical not operator - unary prefix operator

let allowedEntry = false

if !allowedEntry {
   print ("ACCESS DENIED")
}


let enteredDoorCode = true
let retinaScanPassed = false
let iAmTomCruiseFromMI = false

if enteredDoorCode && retinaScanPassed || iAmTomCruiseFromMI{
    print("WELCOME")
} else {
    print("ACCESS DENIED AGAIN")
}


let hasDoorKey = false
let knowOverridePass = true

if hasDoorKey || knowOverridePass{
    print("WELCOME")
} else {
    print("U STILL CANT COME")
}