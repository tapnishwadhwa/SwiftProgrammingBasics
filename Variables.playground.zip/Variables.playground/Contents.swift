//: Playground - noun: a place where people can play

import UIKit

var message = "Hello, playground"

//Operators
//Unary, Binary, Ternary 

var amICool = true
amICool = !amICool
var feelGoodAboutMyself = true
feelGoodAboutMyself = amICool ? true : false
var actBlnc = 1000
var cashRegisterMsg = actBlnc >= 500 ? "You Just Bought the item" : "You are Broke"









